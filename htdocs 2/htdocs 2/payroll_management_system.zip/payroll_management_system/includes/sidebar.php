<div class="contactfinder">
	<h4 class="heading colr">Advertisemet</h4>
	<div><img src="images/add3.jpg" style="width: 250px"></div><br>
</div>